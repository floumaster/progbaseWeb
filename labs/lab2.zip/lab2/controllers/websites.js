const site_rep = require('../repositories/WebsiteRepository.js');
const websiteRepository = new site_rep("data/Websites.json");
module.exports = {
    getWebsites(req, res) {
        res.set("Content-Type", "application/json");
        let page = Number.parseInt(req.param("page") || 1); //2
        let records = Number.parseInt(req.param("per_page") || 5); //3
        if (records > 100)
            records = 100;
        let arr = websiteRepository.getWebsites();
        let record_count = arr.length; //6
        let page_count = Math.ceil(record_count / records); //6/3 = 2
        if (page > page_count) {
            res.send(JSON.stringify([], null, 4));
        } else {
            let left;
            let right;
            if (page_count < page) // 2<=1
            {
                left = (page_count - 1) * records;
                right = record_count;
            } else { //2>1
                left = (page - 1) * records; // 0
                right = left + records; //0+3
            }
            const newArr = arr.slice(left, right);
            res.send(JSON.stringify(newArr, null, 4));
        }
    },
    getWebsitesById(req, res) {
        res.set("Content-Type", "application/json");
        const website = websiteRepository.getWebsitesById(req.params.id)
        if (website === null) {
            res.statusCode = 404;
            res.send(JSON.stringify({ error: 'Website with this id wasnt found' }));
        } else {
            res.send(JSON.stringify(website, null, 4));
        }
    },
    addWebsite(req, res) {
        res.set("Content-Type", "application/json");
        if (req.body.name === undefined || req.body.address === undefined) {
            res.statusCode = 400;
            res.send(JSON.stringify({ error: 'Bad request' }));
        } else {
            res.statusCode = 201;
            res.send(JSON.stringify(websiteRepository.addWebsite(req.body), null, 4));
        }
    },
    updateWebsite(req, res) {
        res.set("Content-Type", "application/json");
        const website = websiteRepository.updateWebsite(req.body)
        if (website === null) {
            res.statusCode = 404;
            res.send(JSON.stringify({ error: 'Any website wasnt updated' }));
        } else if (req.body.name === undefined || req.body.address === undefined) {
            res.statusCode = 400;
            res.send(JSON.stringify({ error: 'Bad request' }));
        } else {
            res.send(JSON.stringify(website, null, 4));
        }
    },
    deleteWebsites(req, res) {
        res.set("Content-Type", "application/json");
        const website = websiteRepository.deleteWebsites(req.params.id)
        if (website === null) {
            res.statusCode = 404;
            res.send(JSON.stringify({ error: 'Website with this id wasnt found' }));
        } else {
            res.send(JSON.stringify(website, null, 4));
        }
    }
};